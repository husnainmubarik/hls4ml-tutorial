//Numpy array shape [5]
//Min -0.089272700250
//Max 0.103989005089
//Number of zeros 0

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
model_default_t b12[5];
#else
model_default_t b12[5] = {-0.0892727003, -0.0258448999, 0.1039890051, -0.0259748362, 0.1034177020};
#endif

#endif
